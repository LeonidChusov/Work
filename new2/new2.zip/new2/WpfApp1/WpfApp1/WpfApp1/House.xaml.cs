﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Models;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для House.xaml
    /// </summary>
    public partial class House : Window
    {
        public House()
        {
            InitializeComponent();
            WindowState = WindowState.Maximized;
            WindowStyle = WindowStyle.None;
            SssContext d = new SssContext();

            userList.ItemsSource = d.Dans.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void userList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void poiskPrice_TextChanged(object sender, TextChangedEventArgs e)
        {
            SssContext d = new SssContext();

            userList.ItemsSource = d.Dans.Where(item =>  item.Price.Contains(poiskPrice.Text)).ToList();
        }

        private void poiskKvadrantmetr_TextChanged(object sender, TextChangedEventArgs e)
        {
            SssContext d = new SssContext();

            userList.ItemsSource = d.Dans.Where(item => item.Metr == poiskKvadrantmetr.Text || item.Metr.Contains(poiskKvadrantmetr.Text)).ToList();
        }

        private void poiskFloot_TextChanged(object sender, TextChangedEventArgs e)
        {
            SssContext d = new SssContext();

            userList.ItemsSource = d.Dans.Where(item => item.FlootKom.Contains(poiskFloot.Text)).ToList();
        }

        private void poiskAtag_TextChanged(object sender, TextChangedEventArgs e)
        {
            SssContext d = new SssContext();

            userList.ItemsSource = d.Dans.Where(item => item.Ittag.Contains(poiskAtag.Text)).ToList();
        }

        private void GridV_ColorChanged(object sender, RoutedPropertyChangedEventArgs<Color> e)
        {

        }

        private void button_Click_3(object sender, RoutedEventArgs e)
        {
            
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
