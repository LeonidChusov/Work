﻿using System;
using System.Collections.Generic;

namespace WpfApp1.Models;

public partial class Usersss
{
    public long Id { get; set; }

    public string Fio { get; set; } = null!;

    public string SreiaNomer { get; set; } = null!;

    public string KemVidan { get; set; } = null!;

    public string AdressReg { get; set; } = null!;

    public string AdresNew { get; set; } = null!;

    public string NomerTelefon { get; set; } = null!;

    public string Datarogden { get; set; } = null!;
}
